const AccountofSetAccount = () => {
  return (
    <div className="AccountofSetAccount">
      <h1>가계부 수정 페이지!</h1>
    </div>
  );
};

export default AccountofSetAccount;
