import AccountEditor from "../components/AccountEditor";

const NewofSetAccount = () => {
  return (
    <div>
      <AccountEditor />
    </div>
  );
};

export default NewofSetAccount;
