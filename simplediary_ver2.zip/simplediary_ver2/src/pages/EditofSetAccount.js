const EditofSetAccount = () => {
  return (
    <div className="EditofSetAccount">
      <h1>가계부 수정 페이지</h1>
    </div>
  );
};

export default EditofSetAccount;
